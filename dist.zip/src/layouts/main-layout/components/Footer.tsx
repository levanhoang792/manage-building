function Footer() {
    return <></>
}

export default Footer;