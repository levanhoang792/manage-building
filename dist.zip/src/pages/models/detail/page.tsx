import {cn} from "@/lib/utils";

export default function ProductDetail() {
    return (
        <div className={cn("p-10")}>
            <h1>Detail</h1>
        </div>
    );
}
