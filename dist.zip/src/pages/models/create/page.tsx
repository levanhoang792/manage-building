import {cn} from "@/lib/utils";

function Create3DModelPage() {
    return (
        <div className={cn("container mx-auto")}>
            <h1>
                Create 3D Model
            </h1>
        </div>
    );
}

export default Create3DModelPage;