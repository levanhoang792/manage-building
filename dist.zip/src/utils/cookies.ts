export const COOKIES = {
    TOKEN: "AuthToken",
    LARAVEL_SESSION: "laravel_session"
}